<?php
function stringSeguro( $string ) {
	$meta = array( '$', '{', '}', '[', ']', '`','<','>','/','!','^','*','(',')','~','|','"','?');
	$escaped = array('&#36', '&#123', '&#125', '&#91', '&#93', '&#96', '&#60', '&#62', '&#47', '&#33','&#94', '&#8727', '&#40', '&#41', '&#126', '&#921', '&#34', '&#63');
	$out =   $string;
	$out = str_replace( $meta, $escaped, $out );
return $out;
}

function stringBack($string){

	$escaped = array('&#36', '&#123', '&#125', '&#91', '&#93', '&#96', '&#60', '&#62', '&#47', '&#33','&#94', '&#8727', '&#40', '&#41', '&#126', '&#921', '&#34', '&#63');
	$meta = array( '$', '{', '}', '', '', '','','','/','!','^','*','(',')','','','"','?');

	$out =  $string;
	$out = str_replace( $escaped, $meta, $out );
return $out;

}

function videos($string){

	$escaped = array('"', '\\');
	$meta = array("'", "");

	$out =  $string;
	$out = str_replace( $escaped, $meta, $out );
return $out;

}


?>