<?php
include('../../libs/db.php');
include('libs/session.php');
include('libs/stringSeguro.php');
include('classes/actividades.php');
include('classes/SimpleImage.php');

$colname_actividades = "-1";
if (isset($_POST['id_actividad'])) {
  $colname_actividades = stringSeguro($_POST['id_actividad']);
}

$actividad1 = stringSeguro($_POST['id_actividad']);

$query_act_categorias = "SELECT * FROM Categorias_actividades ORDER BY id_act_categoria DESC";
$act_categorias = mysql_query($query_act_categorias, $con);
$row_act_categorias = mysql_fetch_assoc($act_categorias);
$totalRows_act_categorias = mysql_num_rows($act_categorias);

$query_actividades = sprintf("SELECT * FROM Actividades WHERE id_actividad = %s", mysql_real_escape_string($colname_actividades, $con));
$actividades = mysql_query($query_actividades, $con);
$row_actividades = mysql_fetch_assoc($actividades);
$totalRows_actividades = mysql_num_rows($actividades);

$query_galeria = sprintf('SELECT * FROM Fotos_actividades WHERE id_actividad ="%s" ORDER BY id_foto ASC', mysql_real_escape_string($actividad1, $con));
$galeria = mysql_query($query_galeria, $con);
$row_galeria = mysql_fetch_assoc($galeria);

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {

    $DOC_FILE1 = $_FILES['act_img']['tmp_name'];
	$DOC_FILE_NAME1 = $_FILES['act_img']['name'];
	$titulo_final = stringSeguro($_POST['act_titulo']);
	$desc_corta_final = strip_tags($_POST['act_desc_corta'],'<span><p><strong><em><a><ul><li><ol><blockquote>');
	$desc_larga_final = strip_tags($_POST['act_desc_larga'],'<span><p><strong><em><a><ul><li><ol><blockquote>');	
	$fecha = stringSeguro($_POST['act_fecha']);
	$video = $_POST['act_video'];
	$categoria = stringSeguro($_POST['id_act_categoria']);
	$id_foto = stringSeguro($_POST['id_foto']);
	$id_galeria = stringSeguro($_POST['id_actividad']);
	
	$nombreImagen = stringSeguro($_POST['img_name']);	
	$descripcion_imagen = stringSeguro($_POST['img_description']);	
	$act_img_2 = stringSeguro($_POST['act_img_2']);
	
	if($_POST['act_video']==NULL){
		$video = stringSeguro($_POST['act_video_2']);
	}else{
		$videol = stringSeguro($_POST['act_video']);
	}
	
	
		if($DOC_FILE1 != NULL){

			$foto = new actividades();
			$foto->editar = 1;
			$foto->nombre = $nombreImagen;
			$foto->descripcion = $descripcion_imagen;
			$foto->archivo = $DOC_FILE_NAME1;
			$foto->id_foto = $id_foto;
		
			$foto1 = $foto->fotos_actividades();
		
			if($foto1){
			
				$photo_name = str_replace(" ", "_", $DOC_FILE_NAME1);
				$thumbs_file_name = str_replace(" ", "_", $DOC_FILE_NAME1);
			
				$photos_download_dir = "../uploads/actividades/galeria_".$id_galeria."/fotos/";				
				$pathtofile = $photos_download_dir .$act_img_2;
				unlink($pathtofile);
				
				$photo_big = new SimpleImage();
				$photo_big->load($DOC_FILE1);
				
				if (($photo_big->getWidth() > 800) || ($photo_big->getHeight() > 600)) {
					if($photo_big->getWidth() > 800){
						$photo_big->resizeToWidth(800);
					}
					
					if($photo_big->getHeight() > 600){	
						$photo_big->resizeToHeight(600);
					}
				}
				
				$photo_big->save($photos_download_dir . $photo_name);
				$thumbs_dir="../uploads/actividades/galeria_".$id_galeria."/thumbs/";
				
				$pathtofile = $thumbs_dir . $act_img_2;
				unlink($pathtofile);
				
				
				$thumb = new SimpleImage();
				$thumb->load($DOC_FILE1);
			
				if (($thumb->getWidth() > 150) || ($thumb->getHeight() > 112)){
			
					if($thumb->getWidth() > 150){
						$thumb->resizeToWidth(150);
					}
			
					if($thumb->getHeight() > 112){
						$thumb->resizeToHeight(112);
					}
				}
				
			$thumb->save($thumbs_dir . $thumbs_file_name);
		
			unlink($DOC_FILE1);	
				
	
			}
		
		}else{
			$DOC_FILE_NAME1 = $_POST['act_img_2'];
		}
		
		
		$actividad = new actividades();
		$actividad->editar = 1;
		$actividad->titulo = $titulo_final;
		$actividad->fecha = $fecha;
		$actividad->desc_corta = $desc_corta_final;
		$actividad->desc_larga = $desc_larga_final;
		$actividad->imagen = $DOC_FILE_NAME1;
		$actividad->video = $video;
		$actividad->categoria = $categoria;
		$actividad->id_actividad = $id_galeria;
		
		$final =  $actividad->actividad();	
		
		if($final){
			header(sprintf("Location: otras_act_home.php"));
		}	
		
  
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/cam_lib_admin.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Caminos de la Libertad</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<link rel="stylesheet" href="tigra_calendar/calendar.css" type="text/css">
<script language="JavaScript" src="tigra_calendar/calendar_db.js" type="text/javascript"></script>
<script language="JavaScript">

function check_fields(inputId){
	var todo_lleno = nada_vacio();
	if(document.getElementById("act_img").value != ""){
		var file_type = checkfileType(inputId);
		if(todo_lleno==false){
			return false;
		}else if(file_type == false){
			return false;
		}else{
			return true;
		}
	}else{
		if(todo_lleno==false){
			return false;
		}else{
			return true;
		}
	}
	
}
function nada_vacio(){
	if(document.getElementById("id_act_categoria").value == 0){
		alert("Selecciona una categor&iacute;a.");
		return false;
	}else if(document.getElementById("act_titulo").value == ""){
		alert("El T&iacute;tulo es obligatorio.");
		return false;
	}else if(document.getElementById("act_fecha").value == ""){
		alert("La Fecha es obligatoria.");
		return false;
	}else if(document.getElementById("act_desc_corta").value == ""){
		alert("Favor de ingresar un descripci&oacute;n corta.");
		return false;
	}else if(document.getElementById("act_desc_larga").value == ""){
		alert("Favor de ingresar un descripci&oacute;n larga.");
		return false;
	}else if(document.getElementById("img_name").value == ""){
		alert("Favor de ingresar un nombre para la imagen.");
		return false;
	}else{
		return true;
	}
}
//Para validar la extensi&oacute;n de los archivos que el usuario quiere subir
function getfileextension(inputId) 
{ 
	var fileinput = document.getElementById(inputId); 
	if(!fileinput ) return ""; 

	var filename = fileinput.value; 
	if( filename.length == 0 ) return ""; 

	var dot = filename.lastIndexOf(".");
	if( dot == -1 ) return ""; 

	var extension = filename.substr(dot,filename.length); 
	return extension; 
} 

function checkfileType(inputId) 
{ 
//alert(document.getElementById(inputId).value);
	if(document.getElementById(inputId).value!=""){
		var ext = getfileextension(inputId);
		//alert(document.getElementById("password").value);
		if((ext == ".jpg") || (ext == ".jpeg") || (ext == ".gif") || (ext == ".png") || (ext == ".JPG") || (ext == ".JPEG") || (ext == ".GIF") || (ext == ".PNG")){ 
			return true;
		}
		else{ 
			alert("Por favor seleccione una imagen con alguna de las siguientes extensiones: .jpg .jpeg .gif .png");
			return false;
		}
	}
}
//-->
</script>
<script type="text/javascript" src="tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "advanced",
		editor_selector : "mceEditor",
		plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

		// Theme options
		//theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons1 : "bold,italic,underline,|,justifyleft,justifycenter,justifyright,justifyfull,fullscreen",		
		theme_advanced_buttons2 : "bullist,numlist,|,undo,redo,|,link,unlink,cleanup,code",
		theme_advanced_buttons3 : "",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		//theme_advanced_statusbar_location : "bottom",
		//theme_advanced_resizing : true,

		// Example content CSS (should be your site CSS)
		//content_css : "css/content.css",
		content_css : "styles.css",

		// Drop lists for link/image/media/template dialogs
		//template_external_list_url : "lists/template_list.js",
		//external_link_list_url : "lists/link_list.js",
		//external_image_list_url : "lists/image_list.js",
		//media_external_list_url : "lists/media_list.js",

		// Replace values for the template plugin
		//template_replace_values : {
		//	username : "Some User",
		//	staffid : "991234"
		//}
	});
</script>
<style type="text/css" media="screen">
	@import url("../css/h_menu.css");
	@import url("../css/admin_tpl.css");
</style>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="main_div">
    <div id="header_top">
        <table align="center" border="0" cellpadding="0" cellspacing="0">
            <tr>
                <td background="../images/header_1.png" style="background-repeat:no-repeat; background-position:center" width="1020px" height="267px">
                    <div id="top_menu">
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="white_border">
                            <tr>
                                <?php switch($_SESSION['loggedin_id_access']){
                                case 1: 
                                    echo "<td><a href='usuarios_home.php'>Usuarios</a></td>";
                                break;
                                } ?>
                                <td><a href="banners_home.php">Banners</a> </td>
                                <td><a href="banners_index_home.php">Banners Carrusel</a> </td>
                                <td><a href="otras_act_home.php">Otras actividades</a></td>
                                <td><a href="recomendaciones_home.php">Recomendaciones</a></td>
                                <td><a href="noticias_home.php">Noticias</a></td>
                                <td><a href="reflexiones_home.php">Reflexiones</a></td> 
                            </tr>
                        </table>
                        <table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
                            <tr>
                                <td><a href="protagonistas_home.php">Protagonistas Libertad</a></td>
                                <td><a href="concursos_home.php">Concursos</a></td>
                                <td><a href="registro_concurso_teatro_home.php">Registro Concurso de Teatro</a></td>
                            </tr>
                        </table>
                    </div>
                </td>
            </tr>
        </table>
    </div><!-- close header_top -->
    
    <div id="content_bottom">
        <table align="center" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="940" height="200px" align="center">
                <table bgcolor="#FFFFFF" width="940px">
                    <tr>
                        <td height="200px"><p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p></td>
                    </tr>
                </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div align="center" style="width:1020px">
                        <table align="center" style="background-color:#FFF;" width="940px" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td>
                                    <table align="center" width="100%" border="0" cellpadding="0" cellspacing="10">
                                        <tr>
                                            <td width="34%" align="left">Bienvenido<strong> <?php echo stringBack($_SESSION['loggedin_username']); ?></strong></td>
                                            <td width="66%" align="right"><strong><a href="cuenta_editar.php">Configuraci&oacute;n
                                            de cuenta</a><a href="<?php echo stringBack($logoutAction); ?>"> / Cerrar
                                            sesi&oacute;n</a></strong></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                <table align="center" width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td valign="top" align="center">
                                        <!--td valign="top" align="center" style="border-left:thin; border-left-style:solid; border-color:#666; border-right:thin; border-right-style:solid; border-color:#666"-->
                                        <!-- InstanceBeginEditable name="body_centro" -->
<form onsubmit="return check_fields('act_img');" method="post" name="form1" id="form1" enctype="multipart/form-data">
  <p>&nbsp;</p>
      <h4>
  	<?php 
		if(isset($mensaje)){
			echo stringBack($mensaje);
		} 
	?>
 </h4>
  <table align="center">
    <tr valign="baseline">
      <td height="25" colspan="3" align="center" valign="middle" nowrap="nowrap" class="listas_headers"><strong>EDITAR ACTIVIDAD</strong></td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap="nowrap">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="top" nowrap="nowrap">Categor&iacute;a:</td>
      <td colspan="2"><label>
          <select name="id_act_categoria" id="id_act_categoria">
          <option value="0">Selecciona una categor&iacute;a</option>
            <?php 
			do {  
			?>
            <option value="<?php echo stringBack($row_act_categorias['id_act_categoria'])?>" <?php if($row_act_categorias['id_act_categoria'] == $_POST['id_act_categoria']){ ?>selected="selected" <? }?>><?php echo stringBack($row_act_categorias['act_categoria'])?></option>
            <?php
			} while ($row_act_categorias = mysql_fetch_assoc($act_categorias));
			  $rows = mysql_num_rows($act_categorias);
			  if($rows > 0) {
				  mysql_data_seek($act_categorias, 0);
				  $row_act_categorias = mysql_fetch_assoc($act_categorias);
			  }
			?>
          </select>
      </label></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="top" nowrap="nowrap">T&iacute;tulo:</td>
      <td colspan="2"><input type="text" name="act_titulo" id="act_titulo" value='<?php echo stringBack($row_actividades['act_titulo']); ?>' size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="top" nowrap="nowrap">Fecha:</td>
      <td colspan="2"><input type="text" name="act_fecha" id="act_fecha" value='<?php echo stringBack($row_actividades['act_fecha']); ?>' size="32" />
       <script language="JavaScript">
		new tcal ({
			// form name
			'formname': 'form1',
			// input name
			'controlname': 'act_fecha'
			});
		</script></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="top">Descripci&oacute;n corta:</td>
      <td colspan="2"><textarea name="act_desc_corta" id="act_desc_corta" class="mceEditor" cols="50" rows="5"><?php echo stringBack($row_actividades['act_desc_corta']); ?></textarea></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="top">Descripci&oacute;n larga:</td>
      <td colspan="2"><textarea name="act_desc_larga" id="act_desc_larga" class="mceEditor" cols="50" rows="30"><?php echo stringBack($row_actividades['act_desc_larga']); ?></textarea></td>
    </tr>
    <tr valign="baseline">
      <td rowspan="2" align="right" valign="top" nowrap="nowrap">Imagen:</td>
      <td colspan="2"><img src="../uploads/actividades/galeria_<?php echo stringBack($row_actividades['id_actividad']); ?>/thumbs/<?php echo stringBack($row_actividades['act_img']); ?>" alt="" name="act_img" width="100" height="75" id="act_img2" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2"><?php echo stringBack($row_actividades['act_img']); ?></td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap="nowrap">&nbsp;</td>
      <td colspan="2"><input type="file" name="act_img" id="act_img" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap="nowrap">*Nombre de la foto:</td>
      <td colspan="2"><input type="text" name="img_name" id="img_name" value='<?php echo stringBack($row_galeria['fot_nombre']); ?>' size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap="nowrap">Descripci&oacute;n de la foto:</td>
      <td colspan="2"><input type="text" name="img_description" id="img_description" value='<?php echo stringBack($row_galeria['fot_descripcion']); ?>' size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="top" nowrap="nowrap">Video (embed Youtube):</td>
      <td colspan="2"><?php echo videos($row_actividades['act_video']); ?></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="top" nowrap="nowrap">Nuevo Embed:</td>
      <td colspan="2"><textarea name="act_video" cols="50" rows="5" id="act_video"></textarea></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td align="center"><input type="button" value="Cancelar" onclick="javascript:history.back();" /></td>
      <td align="center"><input type="submit" value="Actualizar actividad" /></td>
    </tr>
  </table>
  <input type="hidden" name="id_foto" value="<?php echo stringBack($row_galeria['id_foto']); ?>" />
  <input type="hidden" name="id_actividad" value="<?php echo stringBack($row_actividades['id_actividad']); ?>" />
  <input type="hidden" name="act_img_2" id="act_img_2" value="<?php echo stringBack($row_actividades['act_img']);?>" />
  <input type="hidden" name="act_video_2" id="act_video_2" value='<?php echo stringBack($row_actividades['act_video']);?>' />
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="id_galeria" value="<?php echo stringBack($row_actividades['id_galeria']); ?>" />
</form>
<p>&nbsp;</p>
<!-- InstanceEndEditable --></td>
                                    </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                                <td background="../images/footer_1.png" height="132" >&nbsp;</td>
                            </tr>
                        </table>
                    </div>
                </td>
            </tr>
        </table>
    </div><!-- close content_bottom -->
</div><!-- close main_div -->

</body>
<!-- InstanceEnd --></html>
<?php
mysql_free_result($actividades);
?>
